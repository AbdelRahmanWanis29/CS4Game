package game.engine.monsters;
import game.engine.Role;

public class MultiTasker extends Monster {
    private int normalSpeedTurns;
    public MultiTasker(String name, String description, Role role, int energy){
        super(name, description, role, energy);
        normalSpeedTurns = 0;
    }

    public void setNormalSpeedTurns(int normalSpeedTurns) {
        this.normalSpeedTurns = normalSpeedTurns;
    }

    public int getNormalSpeedTurns() {
        return normalSpeedTurns;
    }
}
