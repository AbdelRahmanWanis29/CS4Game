package game.engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import game.engine.dataloader.DataLoader;
import game.engine.exceptions.InvalidMoveException;
import game.engine.exceptions.OutOfEnergyException;
import game.engine.monsters.*;

public class Game {
	private Board board;
	private ArrayList<Monster> allMonsters; 
	private Monster player;
	private Monster opponent;
	private Monster current;
	
	public Game(Role playerRole) throws IOException {
		this.board = new Board(DataLoader.readCards());
		
		this.allMonsters = DataLoader.readMonsters();
		
		this.player = selectRandomMonsterByRole(playerRole);
		this.opponent = selectRandomMonsterByRole(playerRole == Role.SCARER ? Role.LAUGHER : Role.SCARER);
		this.current = player;

		allMonsters.remove(player);
		allMonsters.remove(opponent);

		ArrayList<Monster> stationedMonsters = new ArrayList<>();
		for (Monster m : allMonsters) {
			if (m != player && m != opponent) {
				stationedMonsters.add(m);
			}
		}
		Board.setStationedMonsters(stationedMonsters);
		this.board.initializeBoard(DataLoader.readCells());

	}
	
	public Board getBoard() {
		return board;
	}
	
	public ArrayList<Monster> getAllMonsters() {
		return allMonsters; 
	}
	
	public Monster getPlayer() {
		return player;
	}
	
	public Monster getOpponent() {
		return opponent;
	}
	
	public Monster getCurrent() {
		return current;
	}
	
	public void setCurrent(Monster current) {
		this.current = current;
	}
	
	private Monster selectRandomMonsterByRole(Role role) {
		Collections.shuffle(allMonsters);
	    return allMonsters.stream()
	    		.filter(m -> m.getRole() == role)
	    		.findFirst()
	    		.orElse(null);
	}

	private Monster getCurrentOpponent(){
		if (current == player) {
			return opponent;
		} else {
			return player;
		}
	}

	private int rollDice() {
		Random random = new Random();
		return random.nextInt(6) + 1;
	}

    public void usePowerup() throws OutOfEnergyException {
        if (current.getEnergy() >= Constants.POWERUP_COST) {
            current.executePowerupEffect(getCurrentOpponent());
            current.setEnergy(current.getEnergy() - Constants.POWERUP_COST);
        } else {
            throw new OutOfEnergyException("Not enough energy to use powerup.");
        }
    }

	public void playTurn() throws InvalidMoveException {
		if (current.isFrozen()) {
			current.setFrozen(false);
		} else {
			int diceValue = rollDice();
			board.moveMonster(current, diceValue, getCurrentOpponent());
		}
		switchTurn();
	}

	private void switchTurn() {
		current = getCurrentOpponent();
	}

	private boolean checkWinCondition(Monster monster){
		if(monster.getPosition()==99 && monster.getEnergy()>=1000){
			return true;
		}else{
			return false;
		}
	}

	public Monster getWinner() {
		if (checkWinCondition(player)) {
			return player;
		}
		if (checkWinCondition(opponent)) {
			return opponent;
		}
		return null;
	}


}