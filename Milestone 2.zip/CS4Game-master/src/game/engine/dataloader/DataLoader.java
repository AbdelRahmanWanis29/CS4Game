package game.engine.dataloader;

import game.engine.Role;
import game.engine.cards.Card;
import game.engine.cards.ConfusionCard;
import game.engine.cards.EnergyStealCard;
import game.engine.cards.ShieldCard;
import game.engine.cards.StartOverCard;
import game.engine.cards.SwapperCard;
import game.engine.cells.Cell;
import game.engine.cells.ContaminationSock;
import game.engine.cells.ConveyorBelt;
import game.engine.cells.DoorCell;
import game.engine.exceptions.InvalidCSVFormat;
import game.engine.monsters.Dasher;
import game.engine.monsters.Dynamo;
import game.engine.monsters.Monster;
import game.engine.monsters.MultiTasker;
import game.engine.monsters.Schemer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DataLoader {
    private static final String CARDS_FILE_NAME = "cards.csv";
    private static final String CELLS_FILE_NAME = "cells.csv";
    private static final String MONSTERS_FILE_NAME = "monsters.csv";

    public static ArrayList<Card> readCards() throws IOException {
        ArrayList<Card> cards = new ArrayList();

        BufferedReader br;
        Card card;
        for(br = new BufferedReader(new FileReader("cards.csv")); br.ready(); cards.add(card)) {
            String nextLine = br.readLine();
            String[] data = nextLine.split(",");
            if (data.length != 4 && data.length != 5) {
                System.out.println(data.length);
                throw new InvalidCSVFormat(nextLine);
            }

            String cardType = data[0];
            switch (cardType.hashCode()) {
                case -1850010775:
                    if (!cardType.equals("SHIELD")) {
                        throw new InvalidCSVFormat("Unknown card type: " + cardType);
                    }

                    card = new ShieldCard(data[1], data[2], Integer.parseInt(data[3]));
                    break;
                case -1093378422:
                    if (!cardType.equals("SWAPPER")) {
                        throw new InvalidCSVFormat("Unknown card type: " + cardType);
                    }

                    card = new SwapperCard(data[1], data[2], Integer.parseInt(data[3]));
                    break;
                case 352946087:
                    if (!cardType.equals("ENERGYSTEAL")) {
                        throw new InvalidCSVFormat("Unknown card type: " + cardType);
                    }

                    card = new EnergyStealCard(data[1], data[2], Integer.parseInt(data[3]), Integer.parseInt(data[4]));
                    break;
                case 658116630:
                    if (!cardType.equals("STARTOVER")) {
                        throw new InvalidCSVFormat("Unknown card type: " + cardType);
                    }

                    card = new StartOverCard(data[1], data[2], Integer.parseInt(data[3]), Boolean.parseBoolean(data[4]));
                    break;
                case 1993593830:
                    if (cardType.equals("CONFUSION")) {
                        card = new ConfusionCard(data[1], data[2], Integer.parseInt(data[3]), Integer.parseInt(data[4]));
                        break;
                    }

                    throw new InvalidCSVFormat("Unknown card type: " + cardType);
                default:
                    throw new InvalidCSVFormat("Unknown card type: " + cardType);
            }
        }

        br.close();
        return cards;
    }

    public static ArrayList<Cell> readCells() throws IOException {
        ArrayList<Cell> cells = new ArrayList();

        BufferedReader br;
        Cell cell;
        for(br = new BufferedReader(new FileReader("cells.csv")); br.ready(); cells.add(cell)) {
            String nextLine = br.readLine();
            String[] data = nextLine.split(",");
            if (data.length != 2 && data.length != 3) {
                throw new InvalidCSVFormat(nextLine);
            }

            if (data.length == 2) {
                cell = (Cell)(Integer.parseInt(data[1]) > 0 ? new ConveyorBelt(data[0], Integer.parseInt(data[1])) : new ContaminationSock(data[0], Integer.parseInt(data[1])));
            } else {
                cell = new DoorCell(data[0], Role.valueOf(data[1]), Integer.parseInt(data[2]));
            }
        }

        br.close();
        return cells;
    }

    public static ArrayList<Monster> readMonsters() throws IOException {
        ArrayList<Monster> monsters = new ArrayList();

        BufferedReader br;
        Monster monster;
        for(br = new BufferedReader(new FileReader("monsters.csv")); br.ready(); monsters.add(monster)) {
            String nextLine = br.readLine();
            String[] data = nextLine.split(",");
            if (data.length != 5) {
                throw new InvalidCSVFormat(nextLine);
            }

            String monsterType = data[0];
            switch (monsterType.hashCode()) {
                case -1659827379:
                    if (!monsterType.equals("SCHEMER")) {
                        throw new InvalidCSVFormat("Unknown monster type: " + monsterType);
                    }

                    monster = new Schemer(data[1], data[2], Role.valueOf(data[3]), Integer.parseInt(data[4]));
                    break;
                case -1474769077:
                    if (!monsterType.equals("MULTITASKER")) {
                        throw new InvalidCSVFormat("Unknown monster type: " + monsterType);
                    }

                    monster = new MultiTasker(data[1], data[2], Role.valueOf(data[3]), Integer.parseInt(data[4]));
                    break;
                case 2009355199:
                    if (!monsterType.equals("DASHER")) {
                        throw new InvalidCSVFormat("Unknown monster type: " + monsterType);
                    }

                    monster = new Dasher(data[1], data[2], Role.valueOf(data[3]), Integer.parseInt(data[4]));
                    break;
                case 2031364266:
                    if (monsterType.equals("DYNAMO")) {
                        monster = new Dynamo(data[1], data[2], Role.valueOf(data[3]), Integer.parseInt(data[4]));
                        break;
                    }

                    throw new InvalidCSVFormat("Unknown monster type: " + monsterType);
                default:
                    throw new InvalidCSVFormat("Unknown monster type: " + monsterType);
            }
        }

        br.close();
        return monsters;
    }
}
