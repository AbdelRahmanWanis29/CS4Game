package game.engine.cells;

import game.engine.Board;
import game.engine.monsters.Monster;

public class CardCell extends Cell {
    public CardCell(String name) {
        super(name);
    }

    // implemented this method, wasn't implemented before
    public void onLand(Monster var1, Monster var2) {
        Board.drawCard().performAction(var1,var2);
        this.setMonster(var1);
    }
}
