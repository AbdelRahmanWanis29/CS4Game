package game.engine.cells;

import game.engine.Constants;
import game.engine.interfaces.CanisterModifier;
import game.engine.monsters.Monster;

public class ContaminationSock extends TransportCell implements CanisterModifier {
    public ContaminationSock(String name, int effect) {
        super(name, effect);
    }

    @Override
    public void modifyCanisterEnergy(Monster monster, int energy) {
        monster.alterEnergy(energy);
    }
    @Override
    public void transport(Monster monster) {
        if (monster.isShielded()) {
            monster.setShielded(false);
        } else {
            this.modifyCanisterEnergy(monster, -Constants.SLIP_PENALTY);
        }
        super.transport(monster);
    }

    @Override
    public void onLand(Monster landingMonster, Monster opponentMonster) {
        this.setMonster(landingMonster);
        this.transport(landingMonster);
    }
}