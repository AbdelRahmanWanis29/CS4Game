package game.engine.cells;

import game.engine.monsters.Monster;

public class ConveyorBelt extends TransportCell {
    public ConveyorBelt(String name, int effect) {
        super(name, effect);
    }

    // commented out this method
   // public void onLand(Monster var1, Monster var2) {
     //   super.transport(var1);
    //}

}
