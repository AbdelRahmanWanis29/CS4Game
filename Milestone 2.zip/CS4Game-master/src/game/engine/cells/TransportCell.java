package game.engine.cells;

import game.engine.monsters.Monster;

public abstract class TransportCell extends Cell {
    private int effect;

    public TransportCell(String name, int effect) {
        super(name);
        this.effect = effect;
    }

    public int getEffect() {
        return this.effect;
    }

    public void transport(Monster monster) {
        monster.setPosition(monster.getPosition()+this.effect);
    }

    //added this method
    @Override
    public void onLand(Monster landingMonster, Monster opponentMonster) {
        this.setMonster(landingMonster);
        transport(landingMonster);
    }
}
