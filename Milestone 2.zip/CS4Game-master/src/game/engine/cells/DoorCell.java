package game.engine.cells;

import game.engine.Board;
import game.engine.Role;
import game.engine.interfaces.CanisterModifier;
import game.engine.monsters.Monster;
import java.util.ArrayList;

public class DoorCell extends Cell implements CanisterModifier {
    private Role role;
    private int energy;
    private boolean activated;

    public DoorCell(String name, Role role, int energy) {
        super(name);
        this.role = role;
        this.energy = energy;
        this.activated = false;
    }

    public Role getRole() {
        return this.role;
    }

    public int getEnergy() {
        return this.energy;
    }

    public boolean isActivated() {
        return this.activated;
    }

    public void setActivated(boolean isActivated) {
        this.activated = isActivated;
    }

    public void modifyCanisterEnergy(Monster monster, int canisterValue) {
        if (monster.getRole() == this.role) {
            monster.alterEnergy(canisterValue);
        } else {
            monster.alterEnergy(-canisterValue);
        }
    }


    public void onLand(Monster landingMonster, Monster opponentMonster) {
        this.setMonster(landingMonster);
        ArrayList<Monster> allMonsters = Board.getStationedMonsters();

        if (!this.activated) {
            if (landingMonster.getRole() == this.role) {
                modifyCanisterEnergy(landingMonster, this.energy);
                this.activated = true;
                for (Monster monster : allMonsters) {
                    if (monster.getRole() == landingMonster.getRole())
                        modifyCanisterEnergy(monster, this.energy);
                }
            } else {
                if (landingMonster.isShielded()) {
                    landingMonster.setShielded(false);
                } else {
                    modifyCanisterEnergy(landingMonster, this.energy);
                    this.activated = true;
                    for (Monster monster : allMonsters) {
                        if (monster.getRole() == landingMonster.getRole())
                            modifyCanisterEnergy(monster, this.energy);
                    }
                }
            }
        }
    }
}
