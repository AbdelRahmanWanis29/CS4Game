package game.engine.cells;

import game.engine.monsters.Monster;

public class MonsterCell extends Cell {
    private Monster cellMonster;

    public MonsterCell(String name, Monster cellMonster) {
        super(name);
        this.cellMonster = cellMonster;
    }

    public Monster getCellMonster() {
        return this.cellMonster;
    }


    public void onLand(Monster landingMonster, Monster opponentMonster) {
        if (landingMonster.getRole() == this.cellMonster.getRole()) {
            landingMonster.executePowerupEffect(opponentMonster);
        } else if (landingMonster.getEnergy() > this.cellMonster.getEnergy()) {
            if (landingMonster.isShielded()) {
                landingMonster.setShielded(false);
                this.cellMonster.setEnergy(0);
                this.cellMonster.alterEnergy(landingMonster.getEnergy());

            } else {
                int landingMonsterEnergy = landingMonster.getEnergy();
                landingMonster.setEnergy(0);
                this.cellMonster.setEnergy(0);
                this.cellMonster.alterEnergy(landingMonsterEnergy);
            }
        }
    }
}
