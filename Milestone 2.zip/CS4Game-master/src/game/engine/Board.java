package game.engine;

import java.util.ArrayList;
import java.util.Random;
import game.engine.exceptions.*;
import game.engine.cards.Card;
import game.engine.cells.*;
import game.engine.monsters.Monster;

public class Board {
	private final Cell[][] boardCells;
	private static ArrayList<Monster> stationedMonsters; 
	private static ArrayList<Card> originalCards;
	public static ArrayList<Card> cards;
	
	public Board(ArrayList<Card> readCards) {
		this.boardCells = new Cell[Constants.BOARD_ROWS][Constants.BOARD_COLS];
		stationedMonsters = new ArrayList<Monster>();
		originalCards = readCards;
		cards = new ArrayList<Card>();
        setCardsByRarity();
        reloadCards();
	}
	
	public Cell[][] getBoardCells() {
		return boardCells;
	}
	
	public static ArrayList<Monster> getStationedMonsters() {
		return stationedMonsters;
	}
	
	public static void setStationedMonsters(ArrayList<Monster> stationedMonsters) {
		Board.stationedMonsters = stationedMonsters;
	}

	public static ArrayList<Card> getOriginalCards() {
		return originalCards;
	}
	
	public static ArrayList<Card> getCards() {
		return cards;
	}
	
	public static void setCards(ArrayList<Card> cards) {
		Board.cards = cards;
	}

    private int[] indexToRowCol(int index){
        int row =  index/Constants.BOARD_ROWS;
        int col;
        if (row%2 == 0)
            col = index%Constants.BOARD_COLS;
        else
            col = Constants.BOARD_COLS-1 - (index%Constants.BOARD_COLS);
        return new int[] {row,col};
    }

    private Cell getCell(int index){
        int[] row_column = indexToRowCol(index);
        return boardCells[row_column[0]][row_column[1]];
    }

    private void setCell(int index, Cell cell){
        int[] row_column = indexToRowCol(index);
        boardCells[row_column[0]][row_column[1]] = cell;
    }
    //even = normal
    // odd = DoorCells
    public void initializeBoard(ArrayList<Cell> specialCells) {
        for (int i = 0; i < Constants.BOARD_SIZE; i++) {
            if (i % 2 == 1)
                setCell(i, new DoorCell("Door", Role.SCARER, 0));
            else
                setCell(i, new Cell("Normal"));
        }
        for (int i = 0; i < Constants.CARD_CELL_INDICES.length; i++) {
            int index = Constants.CARD_CELL_INDICES[i];
            setCell(index, new CardCell("Card Cell"));

        }

        int doorIndex = 0;
        for (Cell special : specialCells) {
            if (special instanceof DoorCell) {
                while (doorIndex < Constants.BOARD_SIZE) {
                    if (doorIndex % 2 == 1) {
                        setCell(doorIndex, special);
                        doorIndex++;
                        break;
                    }
                    doorIndex++;
                }
            }
            else if (special instanceof ConveyorBelt) {
                for (int ind : Constants.CONVEYOR_CELL_INDICES) {
                    setCell(ind, new ConveyorBelt(special.getName(), ((TransportCell) special).getEffect()));
                }
            }
            else if (special instanceof ContaminationSock) {
                for (int ind : Constants.SOCK_CELL_INDICES) {
                    setCell(ind, new ContaminationSock(special.getName(), ((TransportCell) special).getEffect()));
                }
            }
        }

            int monsterIndex = 0;
            for (int monsterCell : Constants.MONSTER_CELL_INDICES) {
                if (monsterIndex < stationedMonsters.size()) {
                    Monster stationedMonster = stationedMonsters.get(monsterIndex);
                    MonsterCell mCell = new MonsterCell(stationedMonster.getName(),  stationedMonster);
                    setCell(monsterCell, mCell);
                    stationedMonster.setPosition(monsterCell);
                }
                monsterIndex++;
            }

        }

    private void setCardsByRarity(){
        ArrayList<Card> Rarity = new ArrayList<Card>();
        for(Card card : originalCards){
            int rarity = card.getRarity();
            for(int i = 0 ; i<rarity ; i++)
                Rarity.add(card);
        }
        originalCards =  Rarity;
    }

    public static void reloadCards(){
        cards = new ArrayList<Card>(originalCards);
        Random rand = new Random();
        for(int i = cards.size()-1 ; i>0 ; i--){
            int j = rand.nextInt(i+1);
            Card temp = cards.get(i);
            cards.set(i, cards.get(j));
            cards.set(j, temp);
        }
    }

    public static Card drawCard(){
        if(cards.isEmpty())
            reloadCards();
        return cards.removeFirst();
    }

    public void moveMonster(Monster currentMonster, int roll, Monster opponentMonster) throws InvalidMoveException {
        int old = currentMonster.getPosition();

        currentMonster.move(roll);
        Cell landed = getCell(currentMonster.getPosition());
        landed.onLand(currentMonster, opponentMonster);

        if (currentMonster.getPosition() == opponentMonster.getPosition()) {
            currentMonster.setPosition(old);
            throw new InvalidMoveException();
        }

        if (currentMonster.isConfused()) {
            currentMonster.decrementConfusion();
            opponentMonster.decrementConfusion();
        }

        updateMonsterPositions(currentMonster, opponentMonster);
    }

    private void updateMonsterPositions(Monster player, Monster opponent){
        for(int i = 0 ; i<Constants.BOARD_SIZE;i++){
            Cell cell = getCell(i);
            if(cell != null){
                cell.setMonster(null);
            }
        }
        Cell playerC = getCell(player.getPosition());
        Cell opponentC = getCell(opponent.getPosition());

        if(playerC !=null){
            playerC.setMonster(player);
        }
        if(opponentC !=null){
            opponentC.setMonster(opponent);
        }

        for(Monster stationed : stationedMonsters){
            Cell stationedC = getCell(stationed.getPosition());
            if(stationedC != null){
                stationedC.setMonster(stationed);
            }
        }

    }

}


