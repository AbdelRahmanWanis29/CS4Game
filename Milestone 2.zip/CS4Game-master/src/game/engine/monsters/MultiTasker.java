package game.engine.monsters;

import game.engine.Role;

public class MultiTasker extends Monster {
    private int normalSpeedTurns = 0;

    public MultiTasker(String name, String description, Role role, int energy) {
        super(name, description, role, energy);
    }

    public int getNormalSpeedTurns() {
        return this.normalSpeedTurns;
    }

    public void setNormalSpeedTurns(int normalSpeedTurns) {
        this.normalSpeedTurns = normalSpeedTurns;
    }

    public void executePowerupEffect(Monster opponentMonster) {
        this.setNormalSpeedTurns(2);
    }

    public void move(int distance) {
        if (this.getNormalSpeedTurns() > 0) {
            this.setNormalSpeedTurns(this.getNormalSpeedTurns() - 1);
        } else {
            distance /= 2;
        }

        super.move(distance);
    }
}
