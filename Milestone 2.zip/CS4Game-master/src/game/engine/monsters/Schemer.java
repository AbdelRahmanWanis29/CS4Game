package game.engine.monsters;

import game.engine.Board;
import game.engine.Constants;
import game.engine.Role;

public class Schemer extends Monster {
    public Schemer(String name, String description, Role role, int energy) {
        super(name, description, role, energy);
    }

    private int stealEnergyFrom(Monster target) {
        if (target.getEnergy() >= Constants.SCHEMER_STEAL) {
            target.alterEnergy(-Constants.SCHEMER_STEAL);
            return Constants.SCHEMER_STEAL;
        } else {
            int energy = target.getEnergy();
            target.setEnergy(0);
            if (target instanceof Schemer)
                target.alterEnergy(0);
            if (target instanceof MultiTasker)
                target.alterEnergy(0);
            return energy;
        }
    }

    public void executePowerupEffect(Monster opponenMonster) {
        int totalStolenEnergy = 0;
        totalStolenEnergy += this.stealEnergyFrom(opponenMonster);

        for(Monster monster : Board.getStationedMonsters()) {
            totalStolenEnergy += this.stealEnergyFrom(monster);
        }

        this.alterEnergy(totalStolenEnergy);
    }
}
