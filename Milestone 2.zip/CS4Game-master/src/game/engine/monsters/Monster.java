package game.engine.monsters;

import game.engine.Role;

public abstract class Monster implements Comparable<Monster> {
    private String name;
    private String description;
    private Role role;
    private Role originalRole;
    private int energy;
    private int position;
    private boolean frozen;
    private boolean shielded;
    private int confusionTurns;
    private int freezeTurns;

    public Monster(String name, String description, Role originalRole, int energy) {
        this.name = name;
        this.description = description;
        this.role = originalRole;
        this.originalRole = originalRole;
        this.energy = energy;
        this.position = 0;
        this.frozen = false;
        this.shielded = false;
        this.confusionTurns = 0;
        this.freezeTurns = 0;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Role getRole() {
        return this.role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Role getOriginalRole() {
        return this.originalRole;
    }

    public int getEnergy() {
        return this.energy;
    }

    public void setEnergy(int energy) {
        this.energy = Math.max(0, energy);
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int position) {
        this.position = position % 100;
    }

    public boolean isFrozen() {
        return this.frozen;
    }

    public void setFrozen(boolean frozen) {
        this.frozen = frozen;
    }

    public boolean isShielded() {
        return this.shielded;
    }

    public void setShielded(boolean shielded){ this.shielded=shielded;}

    public int getConfusionTurns() {
        return this.confusionTurns;
    }

    public void setConfusionTurns(int confusionTurns) {
        this.confusionTurns = confusionTurns;
    }

    public int getFreezeTurns() {
        return this.freezeTurns;
    }

    public void setFreezeTurns(int freezeTurns) {
        this.freezeTurns = freezeTurns;
    }

    public int compareTo(Monster other) {
        return this.position - other.position;
    }

    public abstract void executePowerupEffect(Monster var1);

    public boolean isConfused() {
        return this.confusionTurns != 0;
    }

    public void move(int distance) {
        if (this.frozen && this.freezeTurns > 0) {
            --this.freezeTurns;
            if (this.freezeTurns == 0) {
                this.frozen = false;
            }

        } else {
            this.setPosition(this.position + distance);
        }
    }

    public final void alterEnergy(int energy) {

        if (this instanceof Dynamo) {
            energy *= 2;
        }

        if (this instanceof MultiTasker) {
            energy += 200;
        }

        if (this instanceof Schemer) {
            energy += 10;
        }

        if (this.shielded && energy < 0) {
            this.shielded = false;
            return;
        } else {
            if (this.energy+energy<0) {
                this.energy = 0;
            } else {
                this.setEnergy(this.energy+energy); //used the setEnergy here for the energy constrain
            }

        }
    }

    public void decrementConfusion() {
        if (this.confusionTurns > 0) {
            --this.confusionTurns;
            if (this.confusionTurns == 0) {
                this.role = this.originalRole;
            }
        }

    }


}
