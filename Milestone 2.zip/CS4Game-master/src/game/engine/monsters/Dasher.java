package game.engine.monsters;

import game.engine.Role;

public class Dasher extends Monster {
    private int momentumTurns = 0;

    public Dasher(String name, String description, Role role, int energy) {
        super(name, description, role, energy);
    }

    public int getMomentumTurns() {
        return this.momentumTurns;
    }

    public void setMomentumTurns(int momentumTurns) {
        this.momentumTurns = momentumTurns;
    }

    public void executePowerupEffect(Monster opponenMonster) {
        this.setMomentumTurns(3);
    }

    public void move(int distance) {
        if (this.getMomentumTurns() > 0) {
            distance *= 3;
            this.setMomentumTurns(this.getMomentumTurns() - 1);
        } else {
            distance *= 2;
        }

        super.move(distance);
    }
}
